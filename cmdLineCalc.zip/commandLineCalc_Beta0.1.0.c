/**
 * @wlx
 * commandline caculator
 * basic function:elecFee feeDetail toCURRENCY quit help
 * it is a beta version..
 * finished on 2019.10.27
 */
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <windows.h>

#define DEFAULT_COLOR 7
#define MAXSIZE 100
#define RMBTOUSD 0.1415
#define RMBTOJPY 15.3779
typedef enum {BLACK, BLUE, GREEN, TURQ, RED, PURPLE, YELLOW, WHITE} COLOR;
typedef enum {ERRORNAME, RMB, USD, JPY} MYCURRENCY;

char* cmd_gets(char *s, int n, FILE *stream);
char* s_cmdgets(char *st, int n);
void cmdInterpreter(char* readLine, double * const feeptr, double * const elecptr, unsigned short * const flagptr);
char* strheadcmp(char* str1, char* str2);
void argErrReport(char* functionName, short argnumber, short actualargnumber);
void fontcolor(COLOR color, short highlight) {
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), color | (highlight<<3));
}
void defaultcolor(void) {
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 7);   //the default color of cmd
}
short argnumcounter(char* argstr);
MYCURRENCY strtoMYCURRENCY(char* temp);
void demandInput(void) {fontcolor(PURPLE, 0); printf("Input> "); defaultcolor();}
void titleLog(void);

double elecFee(double elec);
void feeDetail(double elec, double fee);
double toCURRENCY(double, MYCURRENCY);
void help(void);

int main(void) {
	titleLog();
	demandInput();
	char temp[MAXSIZE] ="";
	double elec = 0, feeRMB = 0;
	unsigned short callingflag = 0; // 1: elecfee 2:   4:   8:
	while (s_cmdgets(temp, MAXSIZE)) {
		if (*temp) {
			cmdInterpreter(temp, &feeRMB, &elec, &callingflag);
		}
		demandInput();
	}

	return 0;
}

void cmdInterpreter(char* temp, double * const ptrtofeeRMB, double * const ptrtoelec, unsigned short * const ptrtoflag) {
	short argnumber = 0;
	fontcolor(WHITE, 1);
	/*	if (*temp <= 57 && *temp >= 48) {//begin with number
	 *		//normal calculator  //调度场算法
	 *	} else
	 **/
	if (*temp >= 97 && *temp <= 122) {//begin with letter
		if (strheadcmp(temp, "elecfee")) {
			strcpy(temp, strheadcmp(temp, "elecfee"));

			if ((argnumber = argnumcounter(temp)) == 1) {
				printf("%.1f RMB\n", *ptrtofeeRMB = elecFee(*ptrtoelec = atof(temp)));
				*ptrtoflag |= 1;
			} else {
				argErrReport("elecfee", 1, argnumber);
			}
		} else if (strheadcmp(temp, "feedetail")) {
			strcpy(temp, strheadcmp(temp, "feedetail"));

			if (argnumber = argnumcounter(temp)) {
				argErrReport("feedetail", 0, argnumber);
			} else {
				if (*ptrtoflag&1) {
					feeDetail(*ptrtoelec, *ptrtofeeRMB);
				} else {
					fontcolor(RED, 0); 		printf("error: ");
					fontcolor(WHITE, 1); 	printf("No calculation happened before!\n     ? Please call ");
					fontcolor(TURQ, 0);		printf("elecfee");
					fontcolor(WHITE, 1);	puts(" first.");
				}
			}
		} else if (strheadcmp(temp, "tocurrency")) {
			strcpy(temp, strheadcmp(temp, "tocurrency"));

			if ((argnumber = argnumcounter(temp)) == 1) {
				if (*ptrtoflag&1) {
					MYCURRENCY targetCurrency;

					if (targetCurrency = strtoMYCURRENCY(temp)) { //targetCurrency != ERRORNAME
						printf("%.1f\n", toCURRENCY(*ptrtofeeRMB, targetCurrency));
					} else {
						fontcolor(RED, 0); 		printf("error: ");
						fontcolor(WHITE, 1);    printf("Currency \"");
						fontcolor(YELLOW, 0);   printf(temp);
						fontcolor(WHITE, 1);	printf("\" not found.\n     ? Support ");
						fontcolor(YELLOW, 0);	printf("usd rmb jpy");
						fontcolor(WHITE, 1);	puts(" only.");
					}

				} else {
					fontcolor(RED, 0); 		printf("error: ");
					fontcolor(WHITE, 1); 	printf("No calculation happened before!\n     ? Please call ");
					fontcolor(TURQ, 0);		printf("elecfee");
					fontcolor(WHITE, 1);	puts(" first.");
				}
			} else {
				argErrReport("tocurrency", 1, argnumber);
			}

		} else if (strheadcmp(temp, "quit")) {
			strcpy(temp, strheadcmp(temp, "quit"));

			if (argnumber = argnumcounter(temp)) {
				argErrReport("quit", 0, argnumber);
			} else {
				fontcolor(YELLOW, 0);
				puts("Bye!");
				defaultcolor();
				exit(0);
			}
		} else if (strheadcmp(temp, "help")) {
			strcpy(temp, strheadcmp(temp, "help"));

			if (argnumber = argnumcounter(temp)) {
				argErrReport("help", 0, argnumber);
			} else {
				help();
			}
		} else {
			fontcolor(RED, 0); 		printf("error: ");
			fontcolor(WHITE, 1); 	printf("Command doesn't exist!\n     ? Type ");
			fontcolor(TURQ, 0); 	printf("help");
			fontcolor(WHITE, 1); 	printf(" to view all the command available.\n");
		}
	} else {
		fontcolor(RED, 0); 		printf("error: ");
		fontcolor(WHITE, 1); 	printf("Command doesn't exist!\n     ? Type ");
		fontcolor(TURQ, 0); 	printf("help");
		fontcolor(WHITE, 1); 	printf(" to view all the command available.\n");
	}
}

double elecFee(double elec) {
	if (elec < 0) {
		return -1;
	} else if (elec <= 2760) {
		return 0.538*elec;
	} else if (elec <= 4800) {
		return 0.538*2760+(elec-2760)*0.588;
	} else {
		return 0.538*2760+(4800-2760)*0.588+(elec-4800)*0.838;
	}
}

void feeDetail(double elec, double fee) {
	if (elec < 0) {
		puts("ERROR!");
	} else if (elec <= 2760) {
		printf("%.1f * 0.538 = %.1f\n", elec, fee);
	} else if (elec <= 4800) {
		printf("2760 * 0.538 + (%.1f-2760) * 0.588 = %.1f\n", elec, fee);
	} else {
		printf("2760 * 0.538 + (4800-2760) * 0.588 + (%.1f-4800) * 0.838 = %.1f\n", elec, fee);
	}
}

MYCURRENCY strtoMYCURRENCY(char* temp) {
	if (!strcmp(temp, "usd"))
		return USD;
	else if (!strcmp(temp, "jpy"))
		return JPY;
	else if (!strcmp(temp, "rmb"))
		return RMB;
	else
		return ERRORNAME;
}

double toCURRENCY(double feeRMB, MYCURRENCY currency) {
	switch (currency) {
		case USD: return feeRMB*RMBTOUSD; break;
		case JPY: return feeRMB*RMBTOJPY; break;
		case RMB: return feeRMB; break;
	}
}

char* strheadcmp(char* str1, char* str2) { //should be replaced by readByWord();
	while (*str1 && *str2) {
		if (*str1 == *str2) {
			str1++;
			str2++;
		} else {
			return NULL;
		}
	}
	return ((*str1==' '||*str1=='\0') ? (*str1 ? str1+1 : str1) : NULL);
}

char* s_cmdgets(char *st, int n) {
	register char* ret_val;
	register char* find;

	ret_val = cmd_gets(st, n, stdin);
	if (ret_val) {
		find = strchr(st, '\n');        //replace '\n' with '\0'
		if (find)
			*find = '\0';
		else
			while (getchar() != '\n')   //eatline
				continue;
	}
	return ret_val;
}

char* cmd_gets(char *s, int n, FILE *stream) {
	register int c;
	register char *cs;
	cs = s;

	while(--n > 0 && (c = tolower(getc(stream))) != EOF) { //no difference if you use CAPITALS
		if (c == ' ' && (*(cs-1) == ' '||cs == s)) {//always one ' ' no matter how many ' ' there are
			++n;								//and the first char stored will never be ' '
			continue;
		} else if((*cs++ = c) == '\n') {
			if (*(cs-2) == ' ') {				//dispose of the trailing ' '
				*(--cs-1) = '\n';
			}
			break;
		}
	}

	*cs = '\0';
	return (c == EOF && cs == s) ? NULL : s ;
}

short argnumcounter(char* argstr) {
	if (*argstr) {
		short count = 1;
		while (*(++argstr)) {
			if (*argstr == ' ') {++count;}
		}
		return count;
	} else {
		return 0;
	}
}

void argErrReport(char* functionName, short argnumber, short actualargnumber) {
	if (argnumber > actualargnumber) {
		fontcolor(RED, 0); 		printf("error: ");
		fontcolor(WHITE, 1); 	printf("too few ( ");
		fontcolor(YELLOW, 0);	printf("%d", actualargnumber);
		fontcolor(WHITE, 1);	printf(" ) arguments to function ");
	} else if (argnumber < actualargnumber) {
		fontcolor(RED, 0); 		printf("error: ");
		fontcolor(WHITE, 1); 	printf("too many ( ");
		fontcolor(YELLOW, 0);	printf("%d", actualargnumber);
		fontcolor(WHITE, 1);	printf(" ) arguments to function ");
	} else {return;}
	fontcolor(TURQ, 0); 	puts(functionName);
	fontcolor(WHITE, 1); 	printf("     ? Function ");
	fontcolor(TURQ, 0); 	printf(functionName);
	fontcolor(WHITE, 1);	printf(" needs ");
	fontcolor(YELLOW, 0);	printf("%d", argnumber);
	fontcolor(WHITE, 1);	printf(" argument\n");
}

void help(void) {
	puts("   Commands available(not case sensitive):");
	puts("");
	puts("   elecfee    <double>              show the electric fee (in RMB)");
	puts("   feedetail  *void*                show the detail of last calculation");
	puts("   tocurrency <enum{RMB,USA,JPY}>   show the fee in the currency chosen");
	puts("   quit       *void*                exit the calculator");
	puts("");
}

void titleLog(void) {
	fontcolor(WHITE, 1);
	puts("It's a commandline calculator.");
	puts("Basically it can calculate the electric fee in Hangzhou.");
	printf("Type ");
	fontcolor(TURQ, 0); 	printf("help");
	fontcolor(WHITE, 1); 	printf(" to view all the command available.\n");
}







